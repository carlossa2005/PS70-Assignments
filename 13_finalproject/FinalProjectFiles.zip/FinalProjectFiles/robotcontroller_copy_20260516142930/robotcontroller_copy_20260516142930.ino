#include <WiFi.h>
#include <esp_now.h>

uint8_t robotMAC[] = {0x58, 0x8C, 0x81, 0xAD, 0x95, 0x50};

typedef struct {
  int8_t wheelLeft;
  int8_t wheelRight;
  bool   armLeft;
  bool   armRight;
} RobotCmd;

RobotCmd cmd;
esp_now_peer_info_t peerInfo;
bool lastSendOK = false;

void onSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  lastSendOK = (status == ESP_NOW_SEND_SUCCESS);
}

int8_t potToSpeed(int raw, int deadLow, int deadHigh) {
  if (raw < deadLow) {
    return (int8_t)map(raw, 0, deadLow - 1, -15, -1);
  } else if (raw > deadHigh) {
    return (int8_t)map(raw, deadHigh + 1, 4095, 1, 15);
  } else {
    return 0;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(D2, INPUT_PULLUP);

  WiFi.mode(WIFI_STA);
  Serial.print("Controller MAC: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println("ERROR: ESP-NOW init failed");
    return;
  }
  Serial.println("ESP-NOW init OK");

  esp_now_register_send_cb(onSent);

  memcpy(peerInfo.peer_addr, robotMAC, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("ERROR: Failed to add peer — check MAC address");
    return;
  }
  Serial.println("Peer added OK");
}

void loop() {
  int rawL = analogRead(D0);
  int rawR = analogRead(D1);

  cmd.wheelLeft  = potToSpeed(rawL, 60, 90);
  cmd.wheelRight = potToSpeed(rawR, 60, 90);
  cmd.armLeft    = !digitalRead(D2);
  cmd.armRight   = false;

  esp_now_send(robotMAC, (uint8_t *)&cmd, sizeof(cmd));

  // Print everything to serial
  Serial.println("------------------------------");
  Serial.print("Raw L: ");      Serial.print(rawL);
  Serial.print("  Raw R: ");    Serial.println(rawR);
  Serial.print("Speed L: ");    Serial.print(cmd.wheelLeft);
  Serial.print("  Speed R: ");  Serial.println(cmd.wheelRight);
  Serial.print("Button: ");     Serial.println(cmd.armLeft ? "PRESSED" : "not pressed");
  Serial.print("Send: ");       Serial.println(lastSendOK ? "OK" : "FAILED");

  delay(200);  // slower prints so serial is readable
}