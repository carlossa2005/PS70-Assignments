// ============================================================
// ROBOT — Xiao ESP32C3
// Left motor:  IN1→D0  IN2→D1  IN3→D2  IN4→D3
// Right motor: IN1→D4  IN2→D6  IN3→D5  IN4→D7
// Servo:       D10
// ============================================================
#include <WiFi.h>
#include <esp_now.h>
#include <AccelStepper.h>
#include <ESP32Servo.h>

// Pin order matches your working stepper test code
AccelStepper stepL(AccelStepper::HALF4WIRE, D0, D2, D1, D3);  // IN1,IN3,IN2,IN4
AccelStepper stepR(AccelStepper::HALF4WIRE, D4, D5, D6, D7);  // IN1,IN3,IN2,IN4

Servo weapon;
#define SERVO_PIN    D10
#define SERVO_REST   90
#define SERVO_ATTACK 160

typedef struct {
  int8_t wheelLeft;
  int8_t wheelRight;
  bool   armLeft;
  bool   armRight;
} RobotCmd;

volatile RobotCmd latestCmd = {0, 0, false, false};
volatile bool     newData   = false;

const float MAX_SPEED = 500.0;
const float MAX_ACCEL = 400.0;

void onReceive(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  Serial.println("Packet received!");
  if (len == sizeof(RobotCmd)) {
    memcpy((void*)&latestCmd, data, sizeof(RobotCmd));
    newData = true;
    Serial.println("Data copied OK");
  }
}

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    return;
  }
  esp_now_register_recv_cb(onReceive);

  stepL.setMaxSpeed(MAX_SPEED);
  stepL.setAcceleration(MAX_ACCEL);
  stepR.setMaxSpeed(MAX_SPEED);
  stepR.setAcceleration(MAX_ACCEL);

  weapon.attach(SERVO_PIN, 500, 2400);
  weapon.write(SERVO_REST);

  Serial.print("Robot MAC: ");
  Serial.println(WiFi.macAddress());
}

void loop() {
  if (newData) {
    newData = false;

    RobotCmd c;
    c.wheelLeft  = latestCmd.wheelLeft;
    c.wheelRight = latestCmd.wheelRight;
    c.armLeft    = latestCmd.armLeft;
    c.armRight   = latestCmd.armRight;

    stepL.setSpeed( (c.wheelLeft  / 100.0) * MAX_SPEED);
    stepR.setSpeed(-(c.wheelRight / 100.0) * MAX_SPEED);

    if (c.armLeft || c.armRight) weapon.write(SERVO_ATTACK);
    else                         weapon.write(SERVO_REST);
  }

  stepL.runSpeed();
  stepR.runSpeed();
}