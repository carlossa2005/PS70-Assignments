#include <Stepper.h>

#include <ESP32Servo.h>


const int stepsPerRevolution = 2048;

Stepper myStepper(stepsPerRevolution, D0, D1, D2, D3);

Stepper myStepper2(stepsPerRevolution, D4, D5, D6, D7);  // IN1, IN3, IN2, IN4

Servo weapon;  // create a Servo object — you were calling Servo.attach() directly which doesn't work

void setup() {
  Serial.begin(115200);
  myStepper.setSpeed(5);
  myStepper2.setSpeed(5);

  weapon.attach(D10, 500, 2400);

  weapon.write(90);  // start at neutral
}

void loop() {
  myStepper.step(stepsPerRevolution);
  delay(500);

  myStepper2.step(stepsPerRevolution);
  delay(500);

  weapon.write(19);
  delay(500);
  weapon.write(129);
  delay(500);
}